import os
from dotenv import load_dotenv

load_dotenv()

os.environ['GOOGLE_API_KEY'] = "AQ.Ab8RN6LkzgeIL-QjtI_v7AP9ULQiGSBEzj1AfuW2OumYBwPcZw"

class Settings:
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

    EMBEDDING_MODEL = "models/gemini-embedding-001"
    LLM_MODEL = "gemini-2.5-flash"

    VECTOR_TOP_K = 4

settings = Settings()